# Newleaf CSV data dictionary — schema 1.0

journal.json is the canonical lossless representation. CSVs are spreadsheet views;
nested JSON columns retain ingredient/composition/evidence data. Do not restore from CSV alone.

Every CSV has a header, UTF-8 text, CRLF row separators and RFC 4180 double-quote escaping.
Numeric fields use decimal values without thousands separators. Blank numeric cells mean null
(unknown), never zero. Explicit zero is 0. Booleans are true/false. IDs are stable strings.
event_utc is an ISO UTC instant; event_local includes the original offset; zone_id is IANA;
local_date is the preserved ISO date. Date-only rows leave event time cells blank.
context_only rows accompany selection for interpretation and are excluded from summaries.
revision/version are positive integers. JSON maps retain extra nutrient/provider fields.

Text safety: cells beginning with an apostrophe, tab, CR/LF, or whose first non-whitespace
character is = + - @ are prefixed with one apostrophe. Remove exactly one prefix apostrophe
from those protected text cells to reverse escaping. Numeric values are never escaped as text.
Original text is always preserved exactly in journal.json. Units: g, mL, kg, m, seconds, kcal;
sodium in mg. Original quantities and units are retained beside canonical quantities.
Nutrient status is known/estimated/unknown; basis describes consumed vs recipe totals and scaling.
Coverage reports known sums and contributor counts, not inferred actual daily intake.
Daily weight is mean of that date's measurements; no-entry values remain blank.

Table headers document fields. *_json columns are structured JSON. Foreign keys reference
stable record IDs; recipe_version links to immutable ingredient snapshots, not current catalogs.
attachment SHA-256/size verify original exported bytes. integrity.json verifies every archive
member except itself. Export excludes gateway tokens, caches and private transient drafts.
